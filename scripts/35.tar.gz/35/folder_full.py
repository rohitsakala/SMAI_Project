python folder_view_code.py
bash filter_folder.sh